import React ,{useState} from 'react';
import './style.css';

const LoginForm =() => {

    const [criteria1, setCriteria1] = useState('');
  const [criteria2, setCriteria2] = useState('');
  const [predictedGenre, setPredictedGenre] = useState('');
  const [graph, setGraph] = useState(null);


  const handleSubmit = async (e) => {
    e.preventDefault();

    // Make API request to Django backend
    const response = await fetch('http://127.0.0.1:8000/api/predict_genre/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ criteria1: criteria1.split(','), criteria2: criteria2.split(',') }),
    });

    if (response.ok) {
      const data = await response.json();
      setPredictedGenre(data.predicted_genre);
      setGraph(`data:image/png;base64,${data.plot}`);
    } else {
      // Handle error
      console.error('Error predicting genre');
    }
  };


    return (


        
<div>
      <div class="wrapper">
          <form onSubmit={handleSubmit}>
              <h1>Input Criterions </h1>
              <br></br>
              <h4>Conscientiousness as (Disciplined,Responsible,Organised,Cautious)(All in 1-5)</h4>
              
              <div class="input-box">
                  <input type="text" placeholder="Conscientiousness" value={criteria1}
              onChange={(e) => setCriteria1(e.target.value)} required/>
              </div>
               <br>
               </br>
              <h4>Openess as (Imaginative,Artistic,Creative,Adventurous)<br></br> (All in  1-5)</h4>

              <div class="input-box">
                  <input type="text" placeholder="Openess" value={criteria2}
              onChange={(e) => setCriteria2(e.target.value)} required/>
              </div>
              <br></br>
              <button type="submit" class="btn">Submit</button>
  
              
          </form>
      </div>



<div class="wrapper2">
  <h1>Genre:{predictedGenre}</h1>
    {graph && <img src={graph} alt="Graph" style={{width: '100%', height: '90%'}} />}
</div>


</div>


      )
  
  
  
  
  }
  
  export default LoginForm;