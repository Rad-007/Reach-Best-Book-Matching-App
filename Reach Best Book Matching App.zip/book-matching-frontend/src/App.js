import logo from './logo.svg';
import './App.css';
import './style.css'
//import React, { useState } from 'react';

import LoginForm from './Input.js';
import Navbar from './Nav.js';




const App = () => {
  return (
    <div>
      <Navbar/>
      <LoginForm />
    </div>
  );
};

export default App;
